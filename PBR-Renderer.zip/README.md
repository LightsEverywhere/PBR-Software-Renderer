# PBR-Software-Renderer
An software renderer which supports Physically-based rendering, obj model importing, multiple texture channel, etc.
