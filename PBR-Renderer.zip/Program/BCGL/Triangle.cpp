#include "pch.h"
#include "Triangle.h"
#define CRGBtoRGB(c) RGB(c.red*255,c.green*255,c.blue*255)

CTriangle::CTriangle()
{
}

CTriangle::~CTriangle()
{
}